import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ButtonEditor extends DefaultCellEditor {
    private JButton button;
    private String label;
    private boolean isPushed;
    private DatabaseHandler dbHandler;
    private JTable table;
    private int row;

    public ButtonEditor(JCheckBox checkBox, DatabaseHandler dbHandler, JTable table) {
        super(checkBox);
        this.dbHandler = dbHandler;
        this.table = table;
        button = new JButton();
        button.setOpaque(true);
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                fireEditingStopped();
            }
        });
    }

    @Override
    public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
        label = (value == null) ? "" : value.toString();
        button.setText(label);
        isPushed = true;
        this.row = row;
        return button;
    }

    @Override
    public Object getCellEditorValue() {
        if (isPushed) {
            int id = (int) table.getValueAt(row, 0);
            dbHandler.reserveFood(id);

            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    // 更新表格中的數量
                    if (row >= 0 && row < table.getRowCount()) {
                        int currentQuantity = (int) table.getValueAt(row, 2); // 假設quantity在第三列
                        if (currentQuantity > 1) {
                            table.setValueAt(currentQuantity - 1, row, 2);
                        } else {
                            // 刪除該行
                            ((DefaultTableModel) table.getModel()).removeRow(row);
                        }
                    }
                }
            });
        }
        isPushed = false;
        return label;
    }

    @Override
    public boolean stopCellEditing() {
        isPushed = false;
        return super.stopCellEditing();
    }

    @Override
    protected void fireEditingStopped() {
        super.fireEditingStopped();
    }
}


