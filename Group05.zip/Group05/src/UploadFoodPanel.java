import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UploadFoodPanel extends JPanel {
	private DatabaseHandler dbHandler;
	private MainMenuFrame mainMenuFrame;

    public UploadFoodPanel(DatabaseHandler dbHandler,MainMenuFrame mainMenuFrame) {
        this.dbHandler = dbHandler;
        this.mainMenuFrame = mainMenuFrame;
        setLayout(new GridLayout(5, 2));

        JLabel nameLabel = new JLabel("食物名稱:");
        JLabel quantityLabel = new JLabel("數量:");
        JLabel locationLabel = new JLabel("地點:");
        JTextField nameField = new JTextField(15);
        JTextField quantityField = new JTextField(15);
        JTextField locationField = new JTextField(15);
        JButton uploadButton = new JButton("上傳");
        JButton backButton = new JButton("返回");

        uploadButton.addActionListener(e -> {
            String name = nameField.getText();
            int quantity = Integer.parseInt(quantityField.getText());
            String location = locationField.getText();
            dbHandler.uploadFood(name, quantity, location);
            JOptionPane.showMessageDialog(null, "上傳成功!");
        });
        
        backButton.addActionListener(e -> mainMenuFrame.switchToMainMenu());

        add(nameLabel);
        add(nameField);
        add(quantityLabel);
        add(quantityField);
        add(locationLabel);
        add(locationField);
        add(uploadButton);
        add(backButton);
    }
}