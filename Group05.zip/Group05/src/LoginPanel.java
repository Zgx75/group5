import javax.swing.*;
import java.awt.*;

public class LoginPanel extends JPanel {
    private DatabaseHandler dbHandler;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton registerButton;

    public LoginPanel(DatabaseHandler dbHandler) {
        this.dbHandler = dbHandler;
        setLayout(new GridLayout(3, 2));

        JLabel usernameLabel = new JLabel("帳號:");
        JLabel passwordLabel = new JLabel("密碼:");
        usernameField = new JTextField(15);
        passwordField = new JPasswordField(15);
        loginButton = new JButton("登錄");
        registerButton = new JButton("註冊");

        loginButton.addActionListener(e -> {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            dbHandler.loginUser(username, password);
        });

        registerButton.addActionListener(e -> {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            dbHandler.registerUser(username, password);
        });

        add(usernameLabel);
        add(usernameField);
        add(passwordLabel);
        add(passwordField);
        add(loginButton);
        add(registerButton);
    }
}