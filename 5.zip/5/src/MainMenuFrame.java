import javax.swing.*;
import java.awt.*;

public class MainMenuFrame extends JFrame {
    private DatabaseHandler dbHandler;

    public MainMenuFrame(DatabaseHandler dbHandler) {
        this.dbHandler = dbHandler;
        dbHandler.setMainMenuFrame(this);
        setTitle("Main Menu");
        setSize(300, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(2, 1));

        JButton uploadFoodButton = new JButton("上傳食物");
        JButton viewFoodButton = new JButton("瀏覽及預約食物");

        uploadFoodButton.addActionListener(e -> switchToUploadFoodPanel());
        viewFoodButton.addActionListener(e -> switchToViewFoodPanel());

        add(uploadFoodButton);
        add(viewFoodButton);
    }
    
    public void setDatabaseHandler(DatabaseHandler dbHandler) {
        this.dbHandler = dbHandler;
    }

    private void switchToUploadFoodPanel() {
        getContentPane().removeAll();
        add(new UploadFoodPanel(dbHandler, this));
        revalidate();
        repaint();
    }

    private void switchToViewFoodPanel() {
        getContentPane().removeAll();
        add(new ViewFoodPanel(dbHandler, this));
        revalidate();
        repaint();
        
    }
    public void switchToMainMenu() {
        getContentPane().removeAll();
        JButton uploadFoodButton = new JButton("Upload Food");
        JButton viewFoodButton = new JButton("View Food");

        uploadFoodButton.addActionListener(e -> switchToUploadFoodPanel());
        viewFoodButton.addActionListener(e -> switchToViewFoodPanel());

        add(uploadFoodButton);
        add(viewFoodButton);
        revalidate();
        repaint();
    }
}