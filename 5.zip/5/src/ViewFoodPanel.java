import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ViewFoodPanel extends JPanel {
    private DatabaseHandler dbHandler;
    private MainMenuFrame mainMenuFrame;
    private JTable foodTable;

    public ViewFoodPanel(DatabaseHandler dbHandler, MainMenuFrame mainMenuFrame) {
        this.dbHandler = dbHandler;
        this.mainMenuFrame = mainMenuFrame;

        setLayout(new BorderLayout());

        foodTable = new JTable();

        // Load data in a background thread
        loadDataInBackground();

        JScrollPane scrollPane = new JScrollPane(foodTable);
        add(scrollPane, BorderLayout.CENTER);

        JButton backButton = new JButton("Back");
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainMenuFrame.switchToMainMenu();
            }
        });

        add(backButton, BorderLayout.SOUTH);
    }

    private void loadDataInBackground() {
        SwingWorker<Void, Void> worker = new SwingWorker<>() {
            @Override
            protected Void doInBackground() {
                dbHandler.viewFood(foodTable);
                return null;
            }

            @Override
            protected void done() {
                // Once done, update the table's model if needed
                TableColumn reserveColumn = foodTable.getColumn("Reserve");
                reserveColumn.setCellRenderer(new ButtonRenderer());
                reserveColumn.setCellEditor(new ButtonEditor(new JCheckBox(), dbHandler));
            }
        };
        worker.execute();
    }
}

class ButtonRenderer extends JButton implements TableCellRenderer {
    public ButtonRenderer() {
        setOpaque(true);
    }

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        setText((value == null) ? "" : value.toString());
        return this;
    }
}

class ButtonEditor extends DefaultCellEditor {
    private JButton button;
    private String label;
    private boolean isPushed;
    private DatabaseHandler dbHandler;
    private int id;

    public ButtonEditor(JCheckBox checkBox, DatabaseHandler dbHandler) {
        super(checkBox);
        this.dbHandler = dbHandler;
        button = new JButton();
        button.setOpaque(true);
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                fireEditingStopped();
            }
        });
    }

    @Override
    public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
        label = (value == null) ? "" : value.toString();
        button.setText(label);
        isPushed = true;
        id = (int) table.getValueAt(row, 0);
        return button;
    }

    @Override
    public Object getCellEditorValue() {
        if (isPushed) {
            dbHandler.reserveFood(id);
        }
        isPushed = false;
        return label;
    }

    @Override
    public boolean stopCellEditing() {
        isPushed = false;
        return super.stopCellEditing();
    }

    @Override
    protected void fireEditingStopped() {
        super.fireEditingStopped();
    }
}






