import javax.swing.JTable;

public interface DatabaseOperations {
	
	    void registerUser(String username, String password);
	    void loginUser(String username, String password);
	    void uploadFood(String foodName, int quantity, String location);
	    void viewFood(JTable table);
	
}
